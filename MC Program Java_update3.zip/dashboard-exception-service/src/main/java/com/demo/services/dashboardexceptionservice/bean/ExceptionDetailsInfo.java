package com.demo.services.dashboardexceptionservice.bean;

import javax.persistence.Lob;

public class ExceptionDetailsInfo {
	public ExceptionDetailsInfo(Long reqId, String queueType,String status, String comments, byte[] attachment) {
		super();
		this.reqId = reqId;
		this.comments = comments;
		this.queueType = queueType;
		this.status = status;
		this.attachment = attachment;
	}
	public ExceptionDetailsInfo() {
		
	}
	private Long id;
	private Long reqId;
	private String comments;
	private String queueType;
	private String status;
	@Lob
	private byte[] attachment;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getReqId() {
		return reqId;
	}
	public void setReqId(Long reqId) {
		this.reqId = reqId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	}
