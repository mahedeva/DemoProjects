package com.demo.services.dashboardexceptionservice.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;
import com.demo.services.dashboardexceptionservice.bean.ExceptionDetailsInfo;

@Service
public class ExceptionService {
	
	@Autowired
	ExceptionServiceProxy excpProxy;
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	public List<DashboardExceptionInfo> getExcpDetails(String fromDate, String toDate) {
		List excpLst = new ArrayList();
		
		try {
			logger.info("From Date >>>>> "+fromDate);
			System.out.println("To Date >>>>> "+toDate);
			JSONObject filterObject = new JSONObject();
			filterObject.put("fromDate", fromDate);
				filterObject.put("toDate", toDate);
				excpLst = excpProxy.GetExceptionDetails(filterObject.toString() );
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				logger.info(e.getMessage());
				return excpLst;
			}
		 return excpLst; 
	}
	public List<DashboardExceptionInfo> addException(String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  String comments) {
		List excpLst = new ArrayList();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();  
		DashboardExceptionInfo excpDetails= new DashboardExceptionInfo(clientName, excpDesc, excpDet, excpJson, "New", queType, formatter.format(date), formatter.format(date));		
		excpLst = excpProxy.AddExcetionDetail(excpDetails);
		return excpLst;  		
	}
	public List<DashboardExceptionInfo> ResumeException(String reqId) {
		return excpProxy.ResumeExcetionDetail(Long.parseLong(reqId));
	}
	public List<DashboardExceptionInfo> AnalyseException(String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus) {
		return excpProxy.AnalyseExcetionDetail(new ExceptionDetailsInfo(Long.parseLong(analyseReqId), analyseQueueType, analyseStatus, analyseComments, new byte[1024] ));
	}
	public List<DashboardExceptionInfo> showDashboard() {
		return excpProxy.GetExceptionDetail();
	}
}
