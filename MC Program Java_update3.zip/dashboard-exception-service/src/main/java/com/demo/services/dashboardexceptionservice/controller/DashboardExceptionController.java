package com.demo.services.dashboardexceptionservice.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.services.dashboardexceptionservice.services.ExceptionService;
import com.demo.services.dashboardexceptionservice.services.ExceptionServiceProxy;

@Controller
public class DashboardExceptionController {
	
	@Autowired
	ExceptionService excpService;
	
	@RequestMapping("/showdashboard")
	public String showDashboard(Model model)   
	{  
		model.addAttribute("excpLst",excpService.showDashboard() );
	return "ExcpDashboard";  
	} 
	
	@RequestMapping(value="/getExcpDetails", method=RequestMethod.POST)
	public String getExcpDetails(@RequestParam String fromDate, String toDate, Model model)   
	{   
		model.addAttribute("excpLst",excpService.getExcpDetails(fromDate, toDate) );
		
	 return "ExcpDashboard";  
	} 
	
	@RequestMapping("/createExcp")
	public String CreateException()   
	{  		
		return "ExcpPersist";  
	}  
	
	@RequestMapping(value="/addExcpDetail", method=RequestMethod.POST)
	public String addException(@RequestParam String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  String comments, Model model)   
	{  	
		model.addAttribute("excpLst",excpService.addException(clientName, excpDesc, excpDet, queType, excpJson, cmd, comments) );
		model.addAttribute("message", "Exception has been added for "+ clientName);
		return "ExcpDashboard";  
	}  
	@RequestMapping(value="/resumeExcpDetail", method=RequestMethod.POST)
	public String ResumeException(HttpServletRequest req, Model model)   
	{  	
		String reqId = req.getParameter("reqId");
		model.addAttribute("excpLst",excpService.ResumeException(reqId));
		model.addAttribute("message", "Exception has been Resumed for "+ reqId);
		return "ExcpDashboard";  
	}  
		
	@RequestMapping(value="/analyseExcpDetail", method=RequestMethod.POST)
	public String AnalyseException(@RequestParam String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus, Model model)   
	{  	
		System.out.println("reqId = "+ analyseReqId +  "comments = " + analyseComments + "   queType = "+analyseQueueType +"    status = "+analyseStatus);
		model.addAttribute("excpLst",excpService.AnalyseException(analyseReqId, analyseComments, analyseQueueType, analyseStatus));
		model.addAttribute("message", "Exception has been Analysed for "+ analyseReqId);
		return "ExcpDashboard";  
	}  
		
}
;