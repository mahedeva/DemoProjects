package com.demo.services.resumeexceptionservice.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.demo.services.resumeexceptionservice.bean.ExceptionDetails;
import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
import com.demo.services.resumeexceptionservice.repository.ResumeServiceRepository;
@Service
public class ResumeService {
	
	@Autowired
	ResumeServiceRepository resumeRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();

	public List<ExceptionInfo> GetExcetionDetail(){
		return (List<ExceptionInfo>) jdbcTemplate.query("select TOP 20 * from exception_info", new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
	}
	public List<ExceptionInfo> GetExcetionDetails(String filterString){
		logger.info("Entered GetExcetionDetails >>>>>");
		List excpList = new ArrayList();
		String fromDate = "";
		String toDate = "";

		try {
			JSONObject filterObject = new JSONObject(filterString);
			 fromDate = (String) filterObject.get("fromDate");
			 toDate = (String) filterObject.get("toDate");			
		
		
		String queryString = "select * from exception_info where creat_date > '"+fromDate+"' and creat_date < '"+toDate+"' ";
		logger.info("Filter query >>>> "+ queryString);
		excpList =  jdbcTemplate.query(queryString , new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			logger.info(e.getMessage());
			return excpList;
		}	
		return excpList;
	}
	public List<ExceptionInfo> ResumeExcetionDetail( Long reqId){
		logger.info("Entered Resume Exception details >>> "+reqId);		
		
		//ExceptionInfo excpUpd = resumeRepo.findByReqId(reqId);
		String  queryString = "select * from exception_info where req_id = "+reqId;
		ExceptionInfo excpUpd = jdbcTemplate.query(queryString , new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class)).get(0);
		excpUpd.setStatus("Completed");
		excpUpd.setUpdDate(formatter.format(date));
		resumeRepo.save(excpUpd);
		return (List<ExceptionInfo>) resumeRepo.findAll();
	}
	public List<ExceptionInfo> AnalyseExcetionDetail(ExceptionDetails excpInfo){
		logger.info("Analyse Exception details >>> "+excpInfo.toString());		
		
		//ExceptionInfo excpUpd = resumeRepo.findByReqId(excpInfo.getReqId());
		String  selectQuery = "select * from exception_info where req_id = "+excpInfo.getReqId();
		ExceptionInfo excpUpd = jdbcTemplate.query(selectQuery , new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class)).get(0);
		excpUpd.setQueueType(excpInfo.getQueueType());
		excpUpd.setStatus(excpInfo.getStatus());
		excpUpd.setUpdDate(formatter.format(date));
		resumeRepo.save(excpUpd);
		String queryString = "insert into exception_details(req_id, queue_type, status, comments, attachment) values("+excpInfo.getReqId()+ ",'"+excpInfo.getQueueType()+"', '"+excpInfo.getStatus()+"', '"+excpInfo.getComments()+"',RAWTOHEX('"+excpInfo.getAttachment()+"'));";
		logger.info("Analyse query string "+ queryString);
		int affectedrows= jdbcTemplate.update(queryString);
		logger.info("Rows inserted into excp details ="+affectedrows);
		
		return (List<ExceptionInfo>) resumeRepo.findAll();
		
		
	}
}
