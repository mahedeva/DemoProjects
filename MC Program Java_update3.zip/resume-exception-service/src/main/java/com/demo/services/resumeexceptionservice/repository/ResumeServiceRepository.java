package com.demo.services.resumeexceptionservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;

public interface ResumeServiceRepository extends JpaRepository<ExceptionInfo, Long> {
	
}
