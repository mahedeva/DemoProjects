package com.demo.services.AddExceptionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AddExceptionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddExceptionServiceApplication.class, args);
	}
	 
	
	/*@Bean(initMethod = "start", destroyMethod = "stop")
	public Server inMemoryH2DatabaseaServer() throws SQLException {
	    return Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "8012");
	}*/
}
