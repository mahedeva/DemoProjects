package com.demo.services.AddExceptionService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.services.AddExceptionService.bean.ExceptionInfo;
import com.demo.services.AddExceptionService.services.AddExcpService;

@RestController
public class AddExceptionController {

    @Autowired
    AddExcpService addExcpService;

	@PostMapping(
			  value = "/addExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AddExcetionDetail( @RequestBody ExceptionInfo excpInfo){
		return addExcpService.AddExcetionDetail(excpInfo);
		
	}
}
