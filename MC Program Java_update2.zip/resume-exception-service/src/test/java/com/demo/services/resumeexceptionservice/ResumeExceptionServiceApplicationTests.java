package com.demo.services.resumeexceptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeExceptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
