package com.demo.services.resumeexceptionservice;

import org.springframework.boot.context.properties.ConfigurationProperties;

import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("resume-exception-service")
public class Configuration {
int maxRows;
String errorMsg;
public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public int getMaxRows() {
	return maxRows;
}
public void setMaxRows(int maxRows) {
	this.maxRows = maxRows;
}

}
