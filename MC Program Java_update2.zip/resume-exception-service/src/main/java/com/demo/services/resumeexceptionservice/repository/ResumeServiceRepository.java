package com.demo.services.resumeexceptionservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;

public interface ResumeServiceRepository extends CrudRepository<ExceptionInfo, Long> {
	
	ExceptionInfo findByReqId(Long reqId);
}
