package com.demo.services.resumeexceptionservice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.services.resumeexceptionservice.bean.ExceptionDetails;
import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
import com.demo.services.resumeexceptionservice.repository.ResumeServiceRepository;
import com.demo.services.resumeexceptionservice.services.ResumeService;

@RestController
public class ResumeExceptionController {
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();
	
	@Autowired
	Configuration configuration;
	
	@Autowired
	ResumeServiceRepository resumeRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	ResumeService resumeService;
	
	@GetMapping("/getExcp")
	public List<ExceptionInfo> GetExcetionDetail(){
				
		return resumeService.GetExcetionDetail();
				
	}
	@PostMapping(
			  value = "/getExcpDetails", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> GetExcetionDetails(@RequestBody String filterString){
		
		return resumeService.GetExcetionDetails(filterString);
		
	}
	@PostMapping(
			  value = "/resumeExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> ResumeExcetionDetail( @RequestBody Long reqId){
		return resumeService.ResumeExcetionDetail(reqId);
		}

	@PostMapping(
			  value = "/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AnalyseExcetionDetail( @RequestBody ExceptionDetails excpInfo){
		return resumeService.AnalyseExcetionDetail(excpInfo);
	}
	


}
