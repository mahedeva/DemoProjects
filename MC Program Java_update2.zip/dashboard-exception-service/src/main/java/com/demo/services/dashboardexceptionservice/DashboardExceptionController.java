package com.demo.services.dashboardexceptionservice;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.services.dashboardexceptionservice.services.ExceptionService;
import com.demo.services.dashboardexceptionservice.services.ExceptionServiceProxy;

@Controller
public class DashboardExceptionController {
	
	@Autowired
	ExceptionServiceProxy excpProxy;
	@Autowired
	ExceptionService excpService;
	
	
	/*
	@GetMapping("/dashboard")
	public List<DashboardExceptionInfo> getExceptionDetails() {
		List excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.GetExceptionDetail();
		return excpInfoLst;
	}
	@GetMapping("/addExcp")
	public List<DashboardExceptionInfo> AddExcetionDetail() {
		List<DashboardExceptionInfo> excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.AddExcetionDetail();
		return excpInfoLst;
	}
	*/
	@RequestMapping("/showdashboard")
	public String showDashboard(Model model)   
	{  
		model.addAttribute("excpLst",excpService.showDashboard() );
	return "ExcpDashboard";  
	} 
	
	@RequestMapping(value="/getExcpDetails", method=RequestMethod.POST)
	public String getExcpDetails(@RequestParam String fromDate, String toDate, Model model)   
	{   
		model.addAttribute("excpLst",excpService.getExcpDetails(fromDate, toDate) );
		
	 return "ExcpDashboard";  
	} 
	
	/*@RequestMapping("/addExcpDetail")
	public void AddExcetionDetails() {
		List<DashboardExceptionInfo> excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.AddExcetionDetail();
		System.out.println(excpInfoLst.toString());
		
	}*/
	@RequestMapping("/createExcp")
	public String CreateException()   
	{  		
		return "ExcpPersist";  
	}  
	
	@RequestMapping(value="/addExcpDetail", method=RequestMethod.POST)
	public String addException(@RequestParam String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  String comments, Model model)   
	{  	
		model.addAttribute("excpLst",excpService.addException(clientName, excpDesc, excpDet, queType, excpJson, cmd, comments) );
		model.addAttribute("message", "Exception has been added for "+ clientName);
		return "ExcpDashboard";  
	}  
	@RequestMapping(value="/resumeExcpDetail", method=RequestMethod.POST)
	public String ResumeException(HttpServletRequest req, Model model)   
	{  	
		String reqId = req.getParameter("reqId");
		model.addAttribute("excpLst",excpService.ResumeException(reqId));
		model.addAttribute("message", "Exception has been Resumed for "+ reqId);
		return "ExcpDashboard";  
	}  
	
	/*@RequestMapping(value="/analyseExcpDetail1", method=RequestMethod.POST)
	public String AnalyseException1(@RequestParam String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus, Model model)   
	{  	
		
		System.out.println("reqId = "+ analyseReqId +  "comments = " + analyseComments + "   queType = "+analyseQueueType +"    status = "+analyseStatus);
		byte[] attachment = new byte[1024];
		
		model.addAttribute("excpLst",excpProxy.AnalyseExcetionDetail1(new ExceptionDetailsInfo(Long.parseLong(analyseReqId), analyseQueueType, analyseStatus, analyseComments,attachment )));
		model.addAttribute("message", "Exception has been Resumed for "+ analyseReqId);
		return "ExcpDashboard";  
	}  */
	@RequestMapping(value="/analyseExcpDetail", method=RequestMethod.POST)
	public String AnalyseException(@RequestParam String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus, Model model)   
	{  	
		
		System.out.println("reqId = "+ analyseReqId +  "comments = " + analyseComments + "   queType = "+analyseQueueType +"    status = "+analyseStatus);
		model.addAttribute("excpLst",excpService.AnalyseException(analyseReqId, analyseComments, analyseQueueType, analyseStatus));
		model.addAttribute("message", "Exception has been Analysed for "+ analyseReqId);
		return "ExcpDashboard";  
	}  
		
}
;