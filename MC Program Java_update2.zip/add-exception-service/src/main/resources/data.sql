/*insert into exception_info (req_id,client_name, description,exp_detail, request_body, status, creat_date, upd_date,queue_type, comments) 
values (1001,'Client1', '404 Error', 'Page not loaded. Page display 404 error', '{Test:Test}', 'Open', SYSDATE, SYSDATE, 'Error QUEUE', '');
insert into exception_info (req_id,client_name, description,exp_detail, request_body, status, creat_date, upd_date,queue_type, comments) 
values (1002,'Client', 'Null Pointer Exception', 'Page display Null Pointer Exception when click on Help Link ', '{Test:Test}', 'Open', SYSDATE, SYSDATE, 'Error QUEUE', '');
insert into exception_info (req_id,client_name, description,exp_detail, request_body, status, creat_date, upd_date,queue_type, comments) 
values (1003,'Client3', 'Applicaiton is slow', 'Applicaiton is very slow. Its taking more time to render the page', '{Test:Test}', 'Open', SYSDATE, SYSDATE, 'Performance QUEUE', '');

*/