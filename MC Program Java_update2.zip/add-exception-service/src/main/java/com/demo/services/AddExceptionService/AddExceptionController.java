package com.demo.services.AddExceptionService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.services.AddExceptionService.bean.ExceptionInfo;
import com.demo.services.AddExceptionService.repository.AddServiceRepository;
import com.demo.services.AddExceptionService.services.AddExcpService;

@RestController
public class AddExceptionController {
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();
    @Autowired
    AddExcpService addExcpService;
    @Autowired
	AddServiceRepository addRepo;
    @Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	Configuration configuration;
	/*@GetMapping("/addExcp1")
	public List<ExceptionInfo> AddExcetionDetail1(){
		
		List<ExceptionInfo> excpLst = new ArrayList<ExceptionInfo>();		
		String sqlStatements[] = {
        		"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values ('1010','Client1', '404 Error', 'Page not loaded. Page display 404 error', 'Open', SYSDATE, SYSDATE, 'Error QUEUE')",
        };
        Arrays.asList(sqlStatements).forEach(sql -> {
            jdbcTemplate.execute(sql);
        });	
		return jdbcTemplate.query("select * from exception_info",	new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
	}
	@GetMapping("/addExcp")
	public List<ExceptionInfo> AddExcetionDetail(){
		addRepo.save(new ExceptionInfo("Client11", "test", "Not able to login to application", "Test" ,"Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		return addRepo.findAll();
		
	}*/

	@PostMapping(
			  value = "/addExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AddExcetionDetail( @RequestBody ExceptionInfo excpInfo){
		return addExcpService.AddExcetionDetail(excpInfo);
		
	}
}
