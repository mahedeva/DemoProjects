package com.demo.services.AddExceptionService.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.demo.services.AddExceptionService.bean.ExceptionInfo;

import com.demo.services.AddExceptionService.repository.AddServiceRepository;

@Service
public class AddExcpService {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	AddServiceRepository addRepo;
	
	
	public List<ExceptionInfo> AddExcetionDetail( ExceptionInfo excpInfo){
		System.out.println("Add Exception details >>> "+excpInfo.toString());		
		addRepo.save(excpInfo);
		return addRepo.findAll();
	}
}
