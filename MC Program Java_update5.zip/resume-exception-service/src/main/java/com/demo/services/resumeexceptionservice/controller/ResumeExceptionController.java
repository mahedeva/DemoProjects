package com.demo.services.resumeexceptionservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.services.resumeexceptionservice.bean.ExceptionDetails;
import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
import com.demo.services.resumeexceptionservice.services.ResumeService;

@RestController
public class ResumeExceptionController {
	
	@Autowired
	ResumeService resumeService;
	
	@GetMapping("/getExcp")
	public List<ExceptionInfo> GetExcetionDetail(){
				
		return resumeService.getExcetionDetail();
				
	}
	@PostMapping(
			  value = "/getExcpDetails", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> GetExcetionDetails(@RequestBody String filterString){
		
		return resumeService.getExcetionDetails(filterString);
		
	}
	@PostMapping(
			  value = "/resumeExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> ResumeExcetionDetail( @RequestBody Long reqId){
		return resumeService.resumeExcetionDetail(reqId);
		}

	@PostMapping(
			  value = "/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AnalyseExcetionDetail( @RequestBody ExceptionDetails excpInfo){
		return resumeService.analyseExcetionDetail(excpInfo);
	}
	


}
