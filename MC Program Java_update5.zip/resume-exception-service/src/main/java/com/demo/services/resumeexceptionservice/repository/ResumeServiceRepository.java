package com.demo.services.resumeexceptionservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
@Repository
public interface ResumeServiceRepository extends CrudRepository<ExceptionInfo, Long> {
	ExceptionInfo findByReqId(Long reqId);
}
