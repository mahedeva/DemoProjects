package com.demo.services.resumeexceptionservice.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "exception_details",
indexes = {@Index(name = "index1",  columnList="req_id", unique = false)})
public class ExceptionDetails {
	public ExceptionDetails(Long reqId, String comments, String queueType,String status, byte[] attachment) {
		super();
		this.reqId = reqId;
		this.comments = comments;
		this.queueType = queueType;
		this.status = status;
		this.attachment = attachment;
	}
	public ExceptionDetails() {
		
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
    @Column(name = "req_id", nullable = false)
	private Long reqId;
    
    /*@OneToOne
    @JoinColumn(name = "req_id", referencedColumnName = "req_id")
    private ExceptionInfo exceptionInfo;*/
	private String comments;
	private String queueType;
	private String status;
	@Lob
	@Column(name = "attachment", columnDefinition="BLOB")
	private byte[] attachment;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getReqId() {
		return reqId;
	}
	public void setReqId(Long reqId) {
		this.reqId = reqId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
		
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	}
