
CREATE TABLE IF NOT EXISTS exception_info
(
    req_id int IDENTITY,
    client_name varchar(255),
    description varchar(255),
    exp_detail varchar(255),
    request_body varchar(255),
    status varchar(255),
    creat_date datetime,
    upd_date datetime,
    queue_type varchar(255)
);


CREATE TABLE IF NOT EXISTS exception_details
(
    req_id int,
    queue_type varchar(255),
    status varchar(255),
    comments varchar(255),
    attachment BLOB    
);