insert into exception_info (client_name, description,exp_detail, request_body, status, creat_date, upd_date,queue_type) 
values ('Client1', '404 Error', 'Page not loaded. Page display 404 error', '{Test:Test}', 'Open', SYSDATE, SYSDATE, 'Error QUEUE');

