package com.demo.services.resumeexceptionservice.repository;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
//@RunWith( SpringJUnit4ClassRunner.class )
@ExtendWith(SpringExtension.class)
@DataJpaTest
public class ResumeServiceRepositoryTest {
	@Autowired
	ResumeServiceRepository resumeRepo;

	@Test
	public void testResumeExcetionDetail() {
		
		//fail("Not yet implemented");
		List<ExceptionInfo> excpLst = (List<ExceptionInfo>) resumeRepo.findAll();
		//assertTrue(excpLst.size()>=0);
		assertNotNull(excpLst);
	}

	/*@Test
	void testAnalyseExcetionDetail() {
		//fail("Not yet implemented");
	}
*/
}
