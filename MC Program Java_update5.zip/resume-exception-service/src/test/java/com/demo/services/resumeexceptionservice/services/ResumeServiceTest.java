package com.demo.services.resumeexceptionservice.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;
import com.demo.services.resumeexceptionservice.repository.ResumeServiceRepository;

//@RunWith(MockitoJUnitRunner)
public class ResumeServiceTest {

	@Mock
	ResumeServiceRepository resumeRepo;
	
	DataSource dataSource = new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2)
			.addScript("classpath:schema.sql")
		      .addScript("classpath:data.sql")
		      .build();  

	

	@Test
	void testGetExcetionDetail() {
		ResumeService res = new ResumeService();
		res.setDataSource(dataSource);
		System.out.println(res.getExcetionDetail().toString());
		 assertTrue(res.getExcetionDetail().size()>0);
	}

	@Test
	void testGetExcetionDetails() {
//		fail("Not yet implemented");
		ResumeService res = new ResumeService();
		res.setDataSource(dataSource);
		List<ExceptionInfo> excpLst = res.getExcetionDetails("{fromDate:\"2020-08-16\", toDate:\"2020-08-18\"}");	
		System.out.println(excpLst.toString());
		assertTrue(excpLst.size()>=0);
		
	}
	

	@Test
	void testResumeExcetionDetail() {
		//fail("Not yet implemented");
		ResumeService res = new ResumeService();
		resumeRepo = mock(ResumeServiceRepository.class);
		System.out.println(resumeRepo);
		when(resumeRepo.findByReqId(Mockito.anyLong())).thenReturn(new ExceptionInfo());
		 res.resumeExcetionDetail((long) 1);
		//System.out.println(excpLst.toString());
	}

	@Test
	void testAnalyseExcetionDetail() {
		//fail("Not yet implemented");
	}
	 @Test
	  public void testMockito() {
	    List<String> mockList = mock(List.class);
	    mockList.add("First");
	    when(mockList.get(0)).thenReturn("Mockito");
	    when(mockList.get(1)).thenReturn("JCG");
	    assertEquals("Mockito", mockList.get(0));
	    assertEquals("JCG", mockList.get(1));
	  }

}
