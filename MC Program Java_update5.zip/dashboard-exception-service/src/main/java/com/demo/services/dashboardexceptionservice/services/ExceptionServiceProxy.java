package com.demo.services.dashboardexceptionservice.services;

import java.util.List;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;
import com.demo.services.dashboardexceptionservice.bean.ExceptionDetailsInfo;
@Component
@FeignClient(name ="zuul-api-gateway-server")
@RibbonClient(name="resume-exception-service")
public interface ExceptionServiceProxy {

	@GetMapping("/resume-exception-service/getExcp")
	public List<DashboardExceptionInfo> getExceptionDetail();
	@PostMapping(
			  value = "/resume-exception-service/getExcpDetails", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> getExceptionDetails(@RequestBody String filterString);
	
	@GetMapping("/add-exception-service/addExcpDetail")
	public List<DashboardExceptionInfo> addExcetionDetail();
	@PostMapping(
			  value = "/add-exception-service/addExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> addExcetionDetail( @RequestBody DashboardExceptionInfo excpInfo);
	
	@PostMapping(
			  value = "/resume-exception-service/resumeExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> resumeExcetionDetail( @RequestBody Long  reqId);
	
	@GetMapping("/add-exception-service/addExcp")
	public List<DashboardExceptionInfo> addExcetionDetail1();
	
	@PostMapping(
			  value = "/resume-exception-service/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> analyseExcetionDetail1( @RequestBody ExceptionDetailsInfo excpInfo);
	@PostMapping(
			  value = "/resume-exception-service/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> analyseExcetionDetail( @RequestBody ExceptionDetailsInfo excpInfo);


}
