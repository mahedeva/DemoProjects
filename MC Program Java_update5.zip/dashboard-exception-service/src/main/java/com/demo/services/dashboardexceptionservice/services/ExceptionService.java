package com.demo.services.dashboardexceptionservice.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;
import com.demo.services.dashboardexceptionservice.bean.ExceptionDetailsInfo;

@Service
public class ExceptionService {
	
	@Autowired
	ExceptionServiceProxy excpProxy;
	
	public List<DashboardExceptionInfo> getExcpDetails(String fromDate, String toDate) {
		List excpLst = new ArrayList();
		
		try {
			System.out.println("From Date >>>>> "+fromDate);
			System.out.println("To Date >>>>> "+toDate);
			JSONObject filterObject = new JSONObject();
			filterObject.put("fromDate", fromDate);
			
				filterObject.put("toDate", toDate);
			
				excpLst = excpProxy.getExceptionDetails(filterObject.toString() );
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return excpLst;
			}
		 return excpLst; 
	}
	public List<DashboardExceptionInfo> addException(String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  String comments) {
		System.out.println("Action cmd = "+cmd);
		List excpLst = new ArrayList();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();  
		DashboardExceptionInfo excpDetails= new DashboardExceptionInfo(clientName, excpDesc, excpDet, excpJson, "New", queType, formatter.format(date), formatter.format(date));		
		excpLst = excpProxy.addExcetionDetail(excpDetails);
		return excpLst;  		
	}
	public List<DashboardExceptionInfo> resumeException(String reqId) {
		
		return excpProxy.resumeExcetionDetail(Long.parseLong(reqId));
		
	}
	public List<DashboardExceptionInfo> analyseException(String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus) {
		
		return excpProxy.analyseExcetionDetail(new ExceptionDetailsInfo(Long.parseLong(analyseReqId), analyseQueueType, analyseStatus, analyseComments, new byte[1024] ));
		
	}
	public List<DashboardExceptionInfo> showDashboard() {
		return excpProxy.getExceptionDetail();
	}
}
