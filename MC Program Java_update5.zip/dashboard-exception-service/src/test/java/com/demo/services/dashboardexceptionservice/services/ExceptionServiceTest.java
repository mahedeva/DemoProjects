package com.demo.services.dashboardexceptionservice.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class ExceptionServiceTest {
	
	@Autowired
	ExceptionService excpService;

	@Test
	void testGetExcpDetails() {
		//fail("Not yet implemented");
		ExceptionService exceptionService = new ExceptionService();
		System.out.println(exceptionService.showDashboard());
		assertTrue((exceptionService.showDashboard()).size()==5);
	}

	@Test
	void testAddException() {
		//fail("Not yet implemented");
	}

	@Test
	void testResumeException() {
		//fail("Not yet implemented");
		assertTrue((excpService.ResumeException("1001")).size()>0);
	}

	@Test
	void testAnalyseException() {
		//fail("Not yet implemented");
	}

	@Test
	void testShowDashboard() {
		//fail("Not yet implemented");
	}

}
