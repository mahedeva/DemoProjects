package com.demo.services.AddExceptionService.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.demo.services.AddExceptionService.bean.ExceptionInfo;

import com.demo.services.AddExceptionService.repository.AddServiceRepository;

@Service
public class AddExcpServiceImpl implements AddExcpService {
	
	@Autowired
	AddServiceRepository addRepo;
	
	@Override
	public List<ExceptionInfo> addExcetionDetail( ExceptionInfo excpInfo){
		addRepo.save(excpInfo);
		return addRepo.findAll();
	}
}
