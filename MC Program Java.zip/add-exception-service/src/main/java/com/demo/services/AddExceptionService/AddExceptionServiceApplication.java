package com.demo.services.AddExceptionService;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
@EnableDiscoveryClient
public class AddExceptionServiceApplication {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public static void main(String[] args) {
		SpringApplication.run(AddExceptionServiceApplication.class, args);
	}
	 /*@PostConstruct
	    private void initDb() {
	        String sqlStatements[] = {
	        		"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values (1004,'Client1', '404 Error', 'Page not loaded. Page display 404 error', 'Open', SYSDATE, SYSDATE, 'Error QUEUE')",
	        		"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values (1005,'Client2', 'Null Pointer Exception', 'Page display Null Pointer Exception when click on Help Link ', 'Open', SYSDATE, SYSDATE, 'Error QUEUE')",
	        		"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values (1006,'Client3', 'Applicaiton is slow', 'Applicaiton is very slow. Its taking more time to render the page', 'Open', SYSDATE, SYSDATE, 'Performance QUEUE')",

	        };
	 
	        Arrays.asList(sqlStatements).forEach(sql -> {
	            jdbcTemplate.execute(sql);
	        });	
}*/
}
