package com.demo.services.AddExceptionService;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.services.AddExceptionService.bean.ExceptionInfo;

public interface AddServiceRepository extends JpaRepository<ExceptionInfo, Long> {

}