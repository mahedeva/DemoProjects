package com.demo.services.AddExceptionService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.services.AddExceptionService.bean.ExceptionInfo;

@RestController
public class AddExceptionController {
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();
	
	@Autowired
	Configuration configuration;
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	AddServiceRepository addRepo;
	
	@GetMapping("/addExcp1")
	public List<ExceptionInfo> AddExcetionDetail1(){
		
		List<ExceptionInfo> excpLst = new ArrayList<ExceptionInfo>();
		//jdbcTemplate.query("select * from exception_info", excpLst);
		String sqlStatements[] = {
        		"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values ('1010','Client1', '404 Error', 'Page not loaded. Page display 404 error', 'Open', SYSDATE, SYSDATE, 'Error QUEUE')",
        		//"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values (1005,'Client2', 'Null Pointer Exception', 'Page display Null Pointer Exception when click on Help Link ', 'Open', SYSDATE, SYSDATE, 'Error QUEUE')",
        		//"insert into exception_info (req_id,client_name, description,exp_detail, status, creat_date, upd_date,queue_type) values (1006,'Client3', 'Applicaiton is slow', 'Applicaiton is very slow. Its taking more time to render the page', 'Open', SYSDATE, SYSDATE, 'Performance QUEUE')",

        };
 
        Arrays.asList(sqlStatements).forEach(sql -> {
            jdbcTemplate.execute(sql);
        });	
		return jdbcTemplate.query("select * from exception_info",	new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
			
		//return new AddExceptionInfo("Client1", configuration.getErrorMsg(), "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date));
		
	}
	@GetMapping("/addExcp")
	public List<ExceptionInfo> AddExcetionDetail(){
		addRepo.save(new ExceptionInfo("Client11", "test", "Not able to login to application", "Test" ,"Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		 
        	
		//return jdbcTemplate.query("select * from exception_info",	new BeanPropertyRowMapper<AddExceptionInfo>(AddExceptionInfo.class));
			
		return addRepo.findAll();
		
	}
	/*@RequestMapping("/addExcpDetail")
	public List<ExceptionInfo> AddExcetionDetail( ExceptionInfo excpInfo){
		//addRepo.save(new ExceptionInfo("Client11", "test", "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		addRepo.save(excpInfo);        
		//return jdbcTemplate.query("select * from exception_info",	new BeanPropertyRowMapper<AddExceptionInfo>(AddExceptionInfo.class));		
		return addRepo.findAll();
		
	}*/
	@PostMapping(
			  value = "/addExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AddExcetionDetail( @RequestBody ExceptionInfo excpInfo){
		System.out.println("Add Exception details >>> "+excpInfo.toString());		
		addRepo.save(excpInfo);
		return addRepo.findAll();
		
	}

	
}
