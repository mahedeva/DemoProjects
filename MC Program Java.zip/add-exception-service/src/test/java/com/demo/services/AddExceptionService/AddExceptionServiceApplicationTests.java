package com.demo.services.AddExceptionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddExceptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
