package com.mc.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mc.demo.jpa.ExcpDetails;
import com.mc.demo.jpa.ExcpRepository;

@Component
public class ExcpMainService {
	@Autowired
	ExcpRepository excpRepo;
	public ArrayList getExceptionDetails() {
		 
		 return getAllExcp();
	}
	
	public ArrayList addExceptionDetails(ExcpDetails excpDet) {
		ArrayList excpLst = new ArrayList();		
				excpRepo.save(excpDet);
				
				return getAllExcp();
	}
	public ArrayList getAllExcp() {
		ArrayList excpLst = new ArrayList();				
		for(ExcpDetails expDetail: excpRepo.findAll()) {
			System.out.println("Query output: "+expDetail.toString());			
			excpLst.add(expDetail);
		}	
		return excpLst;
	}

}
