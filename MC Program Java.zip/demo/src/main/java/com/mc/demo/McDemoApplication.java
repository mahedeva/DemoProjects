package com.mc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(McDemoApplication.class, args);
	}

}
