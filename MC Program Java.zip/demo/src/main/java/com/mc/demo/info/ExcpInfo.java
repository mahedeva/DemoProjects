package com.mc.demo.info; 
public class ExcpInfo {

	
	public ExcpInfo(int reqId, String clientName, String desc, String expDetail, String status, String updDate,
			String queueType) {
		super();
		this.reqId = reqId;
		this.clientName = clientName;
		this.desc = desc;
		this.expDetail = expDetail;
		this.status = status;
		this.updDate = updDate;
		this.queueType = queueType;
	}
	public int getReqId() {
		return reqId;
	}
	public void setReqId(int reqId) {
		this.reqId = reqId;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getExpDetail() {
		return expDetail;
	}
	public void setExpDetail(String expDetail) {
		this.expDetail = expDetail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUpdDate() {
		return updDate;
	}
	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}
	public int reqId;
	public String clientName;
	public String desc;
	public String expDetail;
	public String status;
	public String updDate;
	public String queueType;
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	public ExcpInfo() {
		
	}
}