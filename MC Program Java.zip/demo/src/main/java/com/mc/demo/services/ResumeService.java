package com.mc.demo.services;

import java.awt.List;

import java.sql.Date;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.mc.demo.info.ExcpInfo;
import com.mc.demo.jpa.ExcpDetails;
import com.mc.demo.jpa.ExcpRepository;


@Component
public class ResumeService {
	@Autowired
	ExcpRepository excpRepo;
	public ArrayList resumeExcption(Long reqId) {
		ArrayList excpInfoLst = new ArrayList();
		ExcpDetails excpUpd = excpRepo.findByReqId(reqId);
		System.out.println(excpUpd.toString());
		excpUpd.setStatus("Completed");
		excpInfoLst.addAll(addExceptionDetails(excpUpd));
				
		return excpInfoLst;
	}
	public ArrayList getExceptionDetails() {
		 ArrayList excpLst = new ArrayList();
		for(ExcpDetails expDetail: excpRepo.findAll()) {
			excpLst.add(expDetail);
		}	
		return excpLst;
	}
	
	public ArrayList addExceptionDetails(ExcpDetails excpDet) {
				excpRepo.save(excpDet);				
				return getExceptionDetails();
	}
	

}
