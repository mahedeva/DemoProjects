package com.mc.demo.controller;  
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.mc.demo.info.ExcpInfo;
import com.mc.demo.jpa.ExcpDetails;
import com.mc.demo.services.ExcpMainService;
import com.mc.demo.services.ResumeService;  
@Controller
public class ExcpController   
{
@Autowired	
ResumeService resumeService;
@Autowired
ExcpMainService excpMainSvc;

@RequestMapping("/dashboard")
public String showDashboard(Model model)   
{  
	/*ExcpInfo excpInfo = new ExcpInfo(1002, "Test1", "404 Error", "Application page showing 404 error", "In progress", "Queue Type", "06-28-2020");
	System.out.println(excpInfo.getClientName());
	System.out.println(excpInfo.getQueueType());	
	System.out.println(excpInfo.getClientName());
	model.addAttribute("clientName", excpInfo.getClientName());
	model.addAttribute("queueType", excpInfo.getQueueType());*/
	ArrayList excpLst = new ArrayList();
	excpLst.addAll(excpMainSvc.getExceptionDetails());
	model.addAttribute("excpLst",excpLst );
return "ExcpDashboard";  
} 
@RequestMapping("/resume")
public String resumeExcp(@RequestParam String clientId, Model model)   
{  	
	ArrayList excpLst = new ArrayList();
	excpLst.addAll(resumeService.resumeExcption(Long.parseLong(clientId)));
	model.addAttribute("excpLst",excpLst );
	model.addAttribute("message", "Exception Resume successful for "+clientId);
return "ExcpDashboard";
}  
@RequestMapping(value="/addExcp", method=RequestMethod.GET)
public String addException()   
{  		
	return "ExcpPersist";  
}  
@RequestMapping(value="/addExcp", method=RequestMethod.POST)
public String addException(@RequestParam String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  Model model)   
{  	
	System.out.println("ACtion cmd = "+cmd);
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();  
	if(cmd!=null && cmd.equalsIgnoreCase("add")) {
	ExcpDetails excpDetails= new ExcpDetails(clientName, excpDesc, excpDet, "New", queType,formatter.format(date), formatter.format(date));
	excpMainSvc.addExceptionDetails(excpDetails);
	model.addAttribute("message", "Exception has been added for "+ clientName);
	ArrayList excpLst = new ArrayList();
	excpLst.addAll(excpMainSvc.getExceptionDetails());
	model.addAttribute("excpLst",excpLst );
	return "ExcpDashboard";  
	}
	return "ExcpPersist";  
}  
@RequestMapping(value="/submitAnalysis", method=RequestMethod.POST)
public String addException(@RequestParam String excpDet, Model model)   
{  	
	System.out.println("Analysis submitted");
	
	model.addAttribute("message", "Exception has been Analysed for "+ excpDet);
	return "ExcpDashboard";  
	
	
}  
}  