package com.mc.demo.jpa;

import org.springframework.data.repository.CrudRepository;

public interface ExcpRepository extends CrudRepository<ExcpDetails, Long> {

	ExcpDetails findByReqId(Long reqId);
}
