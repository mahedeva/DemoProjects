package com.mc.demo.jpa;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ExcpCommandLineRunner implements CommandLineRunner{
	
	@Autowired
	ExcpRepository excpRepo;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Test command line Runner.....");
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();
		excpRepo.save(new ExcpDetails("Client1", "404 Error", "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		for(ExcpDetails expDetail: excpRepo.findAll()) {
			System.out.println("Query output: "+expDetail.toString());
			System.out.println(expDetail.getClientName());
			
		}
		
	}
	
	}
