package com.mc.demo.jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ExcpDetails {
	public ExcpDetails(String clientName, String desc, String expDetail, String status, String queueType, String creatDate,
			String updDate) {
		super();
		this.clientName = clientName;
		this.desc = desc;
		this.expDetail = expDetail;
		this.status = status;
		this.creatDate = creatDate;
		this.updDate = updDate;
		this.queueType = queueType;
	}
	@Override
	public String toString() {
		return "ExcpDetails [reqId=" + reqId + ", clientName=" + clientName + ", desc=" + desc + ", expDetail="
				+ expDetail + ", status=" + status + ", creatDate=" + creatDate + ", updDate=" + updDate
				+ ", queueType=" + queueType + "]";
	}
	protected ExcpDetails() {		
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long reqId;
	public Long getReqId() {
		return reqId;
	}
	public void setReqId(Long reqId) {
		this.reqId = reqId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getExpDetail() {
		return expDetail;
	}
	public void setExpDetail(String expDetail) {
		this.expDetail = expDetail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatDate() {
		return creatDate;
	}
	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}
	public String getUpdDate() {
		return updDate;
	}
	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	private String clientName;
	private String desc;
	private String expDetail;
	private String status;
	private String creatDate;
	private String updDate;
	private String queueType;
}
