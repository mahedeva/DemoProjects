package com.mc.demo.services;

public class AnalyseService {

}
