package com.demo.services.resumeexceptionservice;

import org.springframework.data.repository.CrudRepository;

import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;

public interface ResumeServiceRepository extends CrudRepository<ExceptionInfo, Long> {
	
	ExceptionInfo findByReqId(Long reqId);
}
