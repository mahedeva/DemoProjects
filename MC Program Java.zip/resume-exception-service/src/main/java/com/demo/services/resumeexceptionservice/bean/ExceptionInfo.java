package com.demo.services.resumeexceptionservice.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class ExceptionInfo {
	public ExceptionInfo(String clientName, String desc, String expDetail, String reqBody, String status, String queueType, String creatDate,
			String updDate) {
		super();
		this.clientName = clientName;
		this.description = desc;
		this.expDetail = expDetail;
		this.requestBody =  reqBody;
		this.status = status;
		this.creatDate = creatDate;
		this.updDate = updDate;
		this.queueType = queueType;
	}
/*	@OneToOne(mappedBy="ExceptionInfo", cascade = CascadeType.ALL)
	private ExceptionDetails excpDetails;*/
	
	public ExceptionInfo() {
		
	}
	@Override
	public String toString() {
		return "ExcpDetails [reqId=" + reqId + ", clientName=" + clientName + ", description=" + description + ", expDetail="
				+ expDetail + ", status=" + status + ", creatDate=" + creatDate + ", updDate=" + updDate
				+ ", queueType=" + queueType +"]";
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reqId;
	public Long getReqId() {
		return reqId;
	}
	public void setReqId(Long reqId) {
		this.reqId = reqId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getExpDetail() {
		return expDetail;
	}
	public void setExpDetail(String expDetail) {
		this.expDetail = expDetail;
	}
	/*public ExceptionDetails getExcpDetails() {
		return excpDetails;
	}
	public void setExcpDetails(ExceptionDetails excpDetails) {
		this.excpDetails = excpDetails;
	}*/
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatDate() {
		return creatDate;
	}
	public void setCreatDate(String creatDate) {
		this.creatDate = creatDate;
	}
	public String getUpdDate() {
		return updDate;
	}
	public void setUpdDate(String updDate) {
		this.updDate = updDate;
	}
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}	

	public String getRequestBody() {
		return requestBody;
	}
	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	
	private String clientName;
	private String description;
	private String expDetail;
	private String status;
	private String creatDate;
	private String updDate;
	private String queueType;
	private String requestBody;
	
}
