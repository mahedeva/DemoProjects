package com.demo.services.resumeexceptionservice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.demo.services.resumeexceptionservice.bean.ExceptionInfo;

@RestController
public class ResumeExceptionController {
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    Date date = new Date();
	
	@Autowired
	Configuration configuration;
	
	@Autowired
	ResumeServiceRepository resumeRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@GetMapping("/getExcp")
	public List<ExceptionInfo> GetExcetionDetail(){
		
		return jdbcTemplate.query("select TOP 20 * from exception_info", new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
		//resumeRepo.save(new ExceptionInfo("Client7", "test", "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		//List<ExceptionInfo> excpInfoLst =  resumeRepo.findAll();
		//return new ExceptionInfo("Client4", configuration.getErrorMsg(), "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date));
		//return excpInfoLst;
		
	}
	@PostMapping(
			  value = "/getExcpDetails", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> GetExcetionDetails(@RequestBody String filterString){
		
		List excpList = new ArrayList();
		String fromDate = "";
		String toDate = "";

		try {
			JSONObject filterObject = new JSONObject(filterString);
			 fromDate = (String) filterObject.get("fromDate");
			 toDate = (String) filterObject.get("toDate");			
		
		
		String queryString = "select * from exception_info where creat_date > '"+fromDate+"' and creat_date < '"+toDate+"' ";
		System.out.println("Filter query >>>> "+ queryString);
		excpList =  jdbcTemplate.query(queryString , new BeanPropertyRowMapper<ExceptionInfo>(ExceptionInfo.class));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return excpList;
		}
		//resumeRepo.save(new ExceptionInfo("Client7", "test", "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date)));
		//List<ExceptionInfo> excpInfoLst =  resumeRepo.findAll();
		//return new ExceptionInfo("Client4", configuration.getErrorMsg(), "Not able to login to application", "Open", "Error Queue" ,formatter.format(date), formatter.format(date));
		//return excpInfoLst;
		
		return excpList;
		
	}
	@PostMapping(
			  value = "/resumeExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> ResumeExcetionDetail( @RequestBody Long reqId){
		System.out.println("Resume Exception details >>> "+reqId);		
		
		ExceptionInfo excpUpd = resumeRepo.findByReqId(reqId);
		System.out.println(excpUpd.toString());
		excpUpd.setStatus("Completed");
		excpUpd.setUpdDate(formatter.format(date));
		resumeRepo.save(excpUpd);
		return (List<ExceptionInfo>) resumeRepo.findAll();
		
	}

	@PostMapping(
			  value = "/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<ExceptionInfo> AnalyseExcetionDetail( @RequestBody ExceptionInfo excpInfo){
		System.out.println("Analyse Exception details >>> "+excpInfo.toString());		
		
		ExceptionInfo excpUpd = resumeRepo.findByReqId(excpInfo.getReqId());
		System.out.println(excpUpd.toString());
		System.out.println("Queue Type = "+excpInfo.getQueueType());
		excpUpd.setQueueType(excpInfo.getQueueType());
		excpUpd.setStatus(excpInfo.getStatus());
		excpUpd.setUpdDate(formatter.format(date));
		resumeRepo.save(excpUpd);
		return (List<ExceptionInfo>) resumeRepo.findAll();
		
	}
	


}
