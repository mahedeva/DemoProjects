package com.demo.services.dashboardexceptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DashboardExceptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
