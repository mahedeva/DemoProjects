package com.demo.services.dashboardexceptionservice;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;
@Component
//@FeignClient(name ="add-exception-service", url= "localhost:8010")
//@FeignClient(name ="zuul-api-gateway-server1")
@RibbonClient(name="add-exception-service")
public interface AddExceptionServiceProxy {

	@GetMapping("/add-exception-service/addExcp")
	public List<DashboardExceptionInfo> AddExcetionDetail();
		

}
