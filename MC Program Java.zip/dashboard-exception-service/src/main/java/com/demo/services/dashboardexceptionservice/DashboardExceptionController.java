package com.demo.services.dashboardexceptionservice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;

@Controller
public class DashboardExceptionController {
	
	@Autowired
	ExceptionServiceProxy excpProxy;
	
	/*@Autowired
	AddExceptionServiceProxy addExcpProxy;
	*/
	@GetMapping("/dashboard1")
	public List<DashboardExceptionInfo> getExceptionDetails1() {
		List excpInfoLst = new ArrayList<>();
		excpInfoLst.add(new DashboardExceptionInfo( "Client1", "404", "Not able to login to application","", "Open", "07/11/202", "07/11/202", "Error Queue", ""	));
		return excpInfoLst;

}
	@GetMapping("/dashboard")
	public List<DashboardExceptionInfo> getExceptionDetails() {
		List excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.GetExceptionDetail();
		return excpInfoLst;
	}
	@GetMapping("/addExcp")
	public List<DashboardExceptionInfo> AddExcetionDetail() {
		List<DashboardExceptionInfo> excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.AddExcetionDetail();
		return excpInfoLst;
	}
	
	@RequestMapping("/showdashboard")
	public String showDashboard(Model model)   
	{  
		model.addAttribute("excpLst",excpProxy.GetExceptionDetail() );
	return "ExcpDashboard";  
	} 
	
	@RequestMapping(value="/getExcpDetails", method=RequestMethod.POST)
	public String getExcpDetails(@RequestParam String fromDate, String toDate, Model model)   
	{   
		try {
		System.out.println("From Date >>>>> "+fromDate);
		System.out.println("To Date >>>>> "+toDate);
		JSONObject filterObject = new JSONObject();
		filterObject.put("fromDate", fromDate);
		
			filterObject.put("toDate", toDate);
		
		model.addAttribute("excpLst",excpProxy.GetExceptionDetails(filterObject.toString() ) );
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "ExcpDashboard";
		}
	 return "ExcpDashboard";  
	} 
	
	@RequestMapping("/addExcpDetail")
	public void AddExcetionDetails() {
		List<DashboardExceptionInfo> excpInfoLst = new ArrayList<>();
		excpInfoLst = excpProxy.AddExcetionDetail();
		System.out.println(excpInfoLst.toString());
		//return excpInfoLst;
	}
	@RequestMapping("/createExcp")
	public String CreateException()   
	{  		
		return "ExcpPersist";  
	}  
	
	@RequestMapping(value="/addExcpDetail", method=RequestMethod.POST)
	public String addException(@RequestParam String clientName, String excpDesc, String excpDet,  String queType, String excpJson,String cmd,  String comments, Model model)   
	{  	
		System.out.println("Action cmd = "+cmd);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();  
		if(cmd!=null && cmd.equalsIgnoreCase("add")) {
		DashboardExceptionInfo excpDetails= new DashboardExceptionInfo(clientName, excpDesc, excpDet, excpJson, "New", queType, formatter.format(date), formatter.format(date), comments);		
		model.addAttribute("message", "Exception has been added for "+ clientName);
		
		model.addAttribute("excpLst",excpProxy.AddExcetionDetail(excpDetails) );
		return "ExcpDashboard";  
		}
		return "ExcpPersist";  
	}  
	@RequestMapping(value="/resumeExcpDetail", method=RequestMethod.POST)
	public String ResumeException(HttpServletRequest req, Model model)   
	{  	
		String reqId = req.getParameter("reqId");
		model.addAttribute("excpLst",excpProxy.ResumeExcetionDetail(Long.parseLong(reqId)));
		model.addAttribute("message", "Exception has been Resumed for "+ reqId);
		return "ExcpDashboard";  
	}  
	/*@RequestMapping(value="/analyseExcpDetail1", method=RequestMethod.POST)
	public String AnalyseException1(@RequestParam String reqId, String comments, String queueType, String status, Model model)   
	{  	
		
		System.out.println("reqId = "+ reqId +  "comments = " + comments + "   queType = "+queueType +"    status = "+status);
		model.addAttribute("excpLst",excpProxy.AnalyseExcetionDetail(new DashboardExceptionInfo(Long.parseLong(reqId), queueType, status, comments )));
		model.addAttribute("message", "Exception has been Resumed for "+ reqId);
		return "ExcpDashboard";  
	}  */
	@RequestMapping(value="/analyseExcpDetail", method=RequestMethod.POST)
	public String AnalyseException(@RequestParam String analyseReqId, String analyseComments, String analyseQueueType, String analyseStatus, Model model)   
	{  	
		
		System.out.println("reqId = "+ analyseReqId +  "comments = " + analyseComments + "   queType = "+analyseQueueType +"    status = "+analyseStatus);
		model.addAttribute("excpLst",excpProxy.AnalyseExcetionDetail(new DashboardExceptionInfo(Long.parseLong(analyseReqId), analyseQueueType, analyseStatus, analyseComments )));
		model.addAttribute("message", "Exception has been Resumed for "+ analyseReqId);
		return "ExcpDashboard";  
	}  
		
}
;