package com.demo.services.dashboardexceptionservice;

import java.util.List;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.services.dashboardexceptionservice.bean.DashboardExceptionInfo;
@Component
//@FeignClient(name ="resume-exception-service", url= "localhost:8011")
//@FeignClient(name ="resume-exception-service")
@FeignClient(name ="zuul-api-gateway-server")
@RibbonClient(name="resume-exception-service")
public interface ExceptionServiceProxy {

	@GetMapping("/resume-exception-service/getExcp")
	public List<DashboardExceptionInfo> GetExceptionDetail();
	@PostMapping(
			  value = "/resume-exception-service/getExcpDetails", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> GetExceptionDetails(@RequestBody String filterString);
	
	@GetMapping("/add-exception-service/addExcpDetail")
	public List<DashboardExceptionInfo> AddExcetionDetail();
	@PostMapping(
			  value = "/add-exception-service/addExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> AddExcetionDetail( @RequestBody DashboardExceptionInfo excpInfo);
	
	@PostMapping(
			  value = "/resume-exception-service/resumeExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> ResumeExcetionDetail( @RequestBody Long  reqId);
	
	@GetMapping("/add-exception-service/addExcp")
	public List<DashboardExceptionInfo> AddExcetionDetail1();
	
	@PostMapping(
			  value = "/resume-exception-service/analyseExcpDetail", consumes = "application/json", produces = "application/json")
	public List<DashboardExceptionInfo> AnalyseExcetionDetail( @RequestBody DashboardExceptionInfo excpInfo);


}
